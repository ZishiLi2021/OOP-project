package action;

public class GroupCommand implements ICommand {
    @Override
    public void run() {
        Shop.group();
    }
}
