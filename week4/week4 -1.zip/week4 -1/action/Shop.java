package action;

import model.ShapeShadingType;
import model.ShapeType;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class Shop {


    public static void delete() {
        System.out.println("delete running now");
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) storage1.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group1 = (ArrayList<String>) o.group2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) storage2.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group2 = (ArrayList<String>) o.group2.clone();

        HashSet<String> gOrS = new HashSet<>();
        for (String s : o.group2) {
            gOrS.addAll(Arrays.asList(s.split("")));
        }


        while (!selected2.isEmpty()) {
            Shape s = selected2.get(0);
            int ind = shapeArr2.indexOf(s);

            selected2.remove(0);
            shapePriColor2.remove(ind);
            shapeSecColor2.remove(ind);
            shapeShadingTyp2.remove(ind);
            storage2.remove(ind);
            shapeTypes2.remove(ind);
            shapeArr2.remove(s);

            if (gOrS.contains(ind + "")) {
                for (String s2 : o.group2) {
                    if (s2.contains(ind + "")) group2.remove(s2);
                }
            }
            System.out.println("group2 below");
            System.out.println(group2);
        }

        supDrawer sD = new supDrawer(o.g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,
                group1,

                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2
        );
        o = (supDrawer) CommandHistory.get();
        o.run(o.shapeArr2, o.shapePriColor2, o.shapeSecColor2, o.shapeShadingTyp2, o.selected2, o.storage2, o.shapeTypes2, o.group2);

    }

    public static void UnGroup() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) storage1.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group1 = (ArrayList<String>) o.group2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) storage2.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group2 = (ArrayList<String>) o.group2.clone();

        HashSet<String> gOrS = new HashSet<>();
        for (String s : o.group2) {
            gOrS.addAll(Arrays.asList(s.split("")));
        }
        for (int i = 0; i < o.shapeArr2.size(); i++) {
            if (o.selected2.contains(o.shapeArr2.get(i)) && gOrS.contains(i + "")) {
                String ans = "";
                for (String s : o.group2) {
                    if (s.contains(i + "") && s.length() > ans.length()) ans = s;
                }
                group2.remove(ans);

            }

        }
        System.out.println("UNgroup2 below");
        System.out.println(group2);
        supDrawer sD = new supDrawer(o.g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,
                group1,

                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2
        );
        o = (supDrawer) CommandHistory.get();
        o.run(o.shapeArr2, o.shapePriColor2, o.shapeSecColor2, o.shapeShadingTyp2, o.selected2, o.storage2, o.shapeTypes2, o.group2);
    }


    public static void group() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) storage1.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group1 = (ArrayList<String>) o.group2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) storage2.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group2 = (ArrayList<String>) o.group2.clone();


        StringBuilder group = new StringBuilder();
        for (int i = 0; i < o.shapeArr2.size(); i++) {
            if (o.selected2.contains(o.shapeArr2.get(i))) {
                if (!group2.isEmpty()) {
                    String l = "";
                    for (String s : group2) {
                        if (s.contains(i + "") && s.length() > l.length()) l = s;
                    }
                    if (!l.equals("")) group.append(l);
                    else group.append(i);

                } else group.append(i);

            }
        }
        group2.add(group.toString());
        System.out.println(group2);
        supDrawer sD = new supDrawer(o.g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,
                group1,

                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2
        );
        o = (supDrawer) CommandHistory.get();
        o.run(o.shapeArr2, o.shapePriColor2, o.shapeSecColor2, o.shapeShadingTyp2, o.selected2, o.storage2, o.shapeTypes2, o.group2);


    }


    public static void copy() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) storage1.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group1 = (ArrayList<String>) o.group2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) storage2.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group2 = (ArrayList<String>) o.group2.clone();


        for (int i = 0; i < o.shapeArr2.size(); i++) {
            if (o.selected2.contains(o.shapeArr2.get(i))) {
                double[] stor;
                Shape newShape;

                if (!shapeTypes2.get(i).equals(ShapeType.TRIANGLE)) {
                    if (shapeTypes2.get(i).equals(ShapeType.RECTANGLE)) {
                        newShape = new Rectangle2D.Double(0, 0,
                                storage2.get(i)[2], storage2.get(i)[3]);
                    } else {
                        newShape = new Ellipse2D.Double(0, 0,
                                storage2.get(i)[2], storage2.get(i)[3]);
                    }
                    stor = new double[4];
                    stor[0] = 0;
                    stor[1] = 1;
                    stor[2] = storage2.get(i)[2];
                    stor[3] = storage2.get(i)[3];


                } else {
                    int[] newX = new int[3];
                    int[] newY = new int[3];
                    stor = new double[6];
                    for (int x = 0; x < 3; x++) {
                        newX[x] = (int) storage2.get(i)[x] + 4;
                        stor[x] = newX[x];
                        storage2.get(i)[x] += 4;
                    }
                    for (int y = 0; y < 3; y++) {
                        newX[y] = (int) storage2.get(i)[y + 3] + 4;
                        stor[y + 3] = newX[y];
                        storage2.get(i)[y + 3] += 4;
                    }
                    newShape = new Polygon(newX, newY, 3);
                }
                shapeArr2.add(newShape);
                shapePriColor2.add(o.shapePriColor2.get(i));
                shapeSecColor2.add(o.shapeSecColor2.get(i));
                shapeShadingTyp2.add(o.shapeShadingTyp2.get(i));
                storage2.add(stor);
                shapeTypes2.add(o.shapeTypes2.get(i));
            }

        }
        supDrawer sD = new supDrawer(o.g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,
                group1,

                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2
        );
    }

    public static void paste() {

        supDrawer o = (supDrawer) CommandHistory.get();
        o.run(o.shapeArr2, o.shapePriColor2, o.shapeSecColor2, o.shapeShadingTyp2, o.selected2, o.storage2, o.shapeTypes2, o.group2);


    }

    public static void runP(
            Graphics2D g,
            ArrayList<Shape> shapeArr,
            ArrayList<Color> shapePriColor,
            ArrayList<Color> shapeSecColor,
            ArrayList<ShapeShadingType> shapeShadingTyp,
            ArrayList<Shape> selected,
            ArrayList<double[]> storage,
            ArrayList<ShapeType> shapeTypes) {

        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));
        for (int i = 0; i < shapeArr.size(); i++) {
            if (shapeShadingTyp.get(i).equals(ShapeShadingType.FILLED_IN)) {
                g.setColor(shapePriColor.get(i));
                g.fill(shapeArr.get(i));
            } else if (shapeShadingTyp.get(i).equals(ShapeShadingType.OUTLINE)) {
                g.setColor(shapeSecColor.get(i));
                g.draw(shapeArr.get(i));
            } else {
                g.setColor(shapePriColor.get(i));
                g.fill(shapeArr.get(i));
                g.setColor(shapeSecColor.get(i));
                g.draw(shapeArr.get(i));
            }
            if (selected.contains(shapeArr.get(i))) {
                Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
                g.setStroke(stroke);
                g.setColor(Color.BLACK);
                if (shapeTypes.get(i).equals(ShapeType.RECTANGLE)) {
                    g.draw(new Rectangle2D.Double(storage.get(i)[0] - 5, storage.get(i)[1] - 5, storage.get(i)[2] + 10, storage.get(i)[3] + 10));
                } else if (shapeTypes.get(i).equals(ShapeType.ELLIPSE)) {
                    g.draw(new Ellipse2D.Double(storage.get(i)[0] - 5, storage.get(i)[1] - 5, storage.get(i)[2] + 10, storage.get(i)[3] + 10));
                } else if (shapeTypes.get(i).equals(ShapeType.TRIANGLE)) {

                    int xMin = Math.min(Math.min((int) storage.get(i)[0], (int) storage.get(i)[1]), (int) storage.get(i)[2]);
                    int xMax = Math.max(Math.max((int) storage.get(i)[0], (int) storage.get(i)[1]), (int) storage.get(i)[2]);
                    int yMin = Math.min(Math.min((int) storage.get(i)[3], (int) storage.get(i)[4]), (int) storage.get(i)[5]);
                    int yMax = Math.max(Math.max((int) storage.get(i)[3], (int) storage.get(i)[4]), (int) storage.get(i)[5]);
                    int xMid = (xMax + xMin) / 2;
                    int yMid = (yMax + yMin) / 2;
                    int[] x = new int[3];
                    int[] y = new int[3];
                    for (int i2 = 0; i2 < 3; i2++) {
                        if (storage.get(i)[i2] < xMid) x[i2] = (int) storage.get(i)[i2] - 5;
                        else x[i2] = (int) storage.get(i)[i2] + 5;
                    }
                    for (int i2 = 3; i2 < 6; i2++) {
                        if (storage.get(i)[i2] < yMid) y[i2 - 3] = (int) storage.get(i)[i2] - 5;
                        else y[i2 - 3] = (int) storage.get(i)[i2] + 5;
                    }
                    g.draw(new Polygon(x, y, 3));

                }
                g.setStroke(new BasicStroke(5));
            }

        }
    }


}

