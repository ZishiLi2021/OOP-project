package action;

public abstract class functionShop {
    public abstract void run();
}
