package action;

import action.Factory.AbstractFactory;
import action.Factory.FactoryProducer;

public class PasteCommand implements ICommand {
    public void run() {
        AbstractFactory a = FactoryProducer.getFactory();
        a.getAction("paste").run();
        new paste().run();
    }
}
