package action.Factory;

public interface actionFactory {
    void run();
}
