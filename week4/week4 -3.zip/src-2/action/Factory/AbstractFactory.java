package action.Factory;

public abstract class AbstractFactory {
    public abstract actionFactory getAction(String a);
}
