package action.Factory;

public class FactoryProducer {
    public static AbstractFactory getFactory() {
        return new actionFac();
    }
}
