package action.Factory;

import action.copy;
import action.paste;

public class actionFac extends AbstractFactory {
    @Override
    public actionFactory getAction(String a) {
        if (a == null) {
            return null;
        }
        if (a.equals("copy")) return new copy();
        else return new paste();
    }
}
