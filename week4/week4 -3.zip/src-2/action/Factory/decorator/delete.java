package action.Factory.decorator;

import action.Factory.actionFac;

public class delete extends decorator {

    public delete(actionFac d) {
        super(d);
    }

    @Override
    public void run() {
        return;
    }
}
