package action.Factory.decorator;

import action.Factory.actionFac;
import action.Factory.actionFactory;

public class decorator implements actionFactory {
    protected actionFac d;

    public decorator(actionFac d) {
        this.d = d;
    }

    @Override
    public void run() {
    }
}
