package action;

import action.Factory.actionFactory;

public class paste extends functionShop
        implements actionFactory {
    @Override
    public void run() {
        supDrawer o = (supDrawer) CommandHistory.get();
        o.run(o.shapeArr2, o.shapePriColor2, o.shapeSecColor2, o.shapeShadingTyp2, o.selected2, o.storage2, o.shapeTypes2, o.group2);
    }
}
