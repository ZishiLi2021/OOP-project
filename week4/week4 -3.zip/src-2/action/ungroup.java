package action;

import model.ShapeShadingType;
import model.ShapeType;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class ungroup extends functionShop {
    @Override
    public void run() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) storage1.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group1 = (ArrayList<String>) o.group2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) storage2.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group2 = (ArrayList<String>) o.group2.clone();

        HashSet<String> gOrS = new HashSet<>();
        for (String s : o.group2) {
            gOrS.addAll(Arrays.asList(s.split("")));
        }
        for (int i = 0; i < o.shapeArr2.size(); i++) {
            if (o.selected2.contains(o.shapeArr2.get(i)) && gOrS.contains(i + "")) {
                String ans = "";
                for (String s : o.group2) {
                    if (s.contains(i + "") && s.length() > ans.length()) ans = s;
                }
                group2.remove(ans);

            }

        }


        supDrawer sD = new supDrawer(o.g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,
                group1,

                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2
        );
        o = (supDrawer) CommandHistory.get();
        o.run(o.shapeArr2, o.shapePriColor2, o.shapeSecColor2, o.shapeShadingTyp2, o.selected2, o.storage2, o.shapeTypes2, o.group2);

    }
}
