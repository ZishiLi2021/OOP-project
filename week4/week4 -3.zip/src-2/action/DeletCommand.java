package action;

public class DeletCommand implements ICommand {
    @Override
    public void run() {
        new delete().run();
    }
}
