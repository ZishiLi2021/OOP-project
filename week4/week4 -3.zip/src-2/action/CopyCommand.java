package action;

import action.Factory.AbstractFactory;
import action.Factory.FactoryProducer;

public class CopyCommand implements ICommand {
    @Override
    public void run() {
        AbstractFactory a = FactoryProducer.getFactory();
        a.getAction("copy").run();
//        new copy().run();
    }
}
