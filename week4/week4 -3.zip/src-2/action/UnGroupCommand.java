package action;

public class UnGroupCommand implements ICommand {
    @Override
    public void run() {
        new ungroup().run();
    }
}
