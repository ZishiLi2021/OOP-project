package action;

public class DeletCommand implements ICommand {
    @Override
    public void run() {
        Shop.delete();
    }
}
