package action;

public interface IUndoable {
    void undo();

    void redo();
}
