package action;

import model.ShapeShadingType;
import model.ShapeType;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class supDrawer implements IUndoable {
    Graphics2D g;
    public final ArrayList<Shape> shapeArr;
    public final ArrayList<Color> shapePriColor;
    public final ArrayList<Color> shapeSecColor;
    public final ArrayList<ShapeShadingType> shapeShadingTyp;
    public final ArrayList<Shape> selected;
    public final ArrayList<double[]> storage;
    public final ArrayList<ShapeType> shapeTypes;
    public final ArrayList<String> group;

    public final ArrayList<Shape> shapeArr2;
    public final ArrayList<Color> shapePriColor2;
    public final ArrayList<Color> shapeSecColor2;
    public final ArrayList<ShapeShadingType> shapeShadingTyp2;
    public final ArrayList<Shape> selected2;
    public final ArrayList<double[]> storage2;
    public final ArrayList<ShapeType> shapeTypes2;
    public final ArrayList<String> group2;

    public ArrayList<Shape> get() {
        return shapeArr2;
    }


    @Override
    public void undo() {
        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));
        run(shapeArr,
                shapePriColor,
                shapeSecColor,
                shapeShadingTyp,
                selected,
                storage,
                shapeTypes,
                group);
    }

    @Override
    public void redo() {
        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));
        run(shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2);
    }

    public void drawGroup(int i,
                          ArrayList<double[]> storage,
                          ArrayList<ShapeType> shapeTypes,
                          ArrayList<String> group) {
        String ans = "";
        String ind = i + "";
        for (String s : group) {
            if (s.contains(ind) && s.length() > ans.length()) ans = s;
        }
        ArrayList<Integer> num = new ArrayList<>();
        for (String s2 : ans.split("")) num.add(Integer.parseInt(s2));
        double xTop = Integer.MAX_VALUE;
        double yTop = Integer.MAX_VALUE;
        double xbut = 0;
        double ybut = 0;
        double length = 0;
        double width = 0;

//        double xMax = 0;
//        double xMin = Integer.MAX_VALUE;
//        double yMax = 0;
//        double yMin = Integer.MAX_VALUE;

        for (int shape : num) {
            if (storage.get(shape).length == 4) {
                double x1 = storage.get(shape)[0];
                double y1 = storage.get(shape)[1];
                double x2 = x1 + storage.get(shape)[2];
                double y2 = y1 + storage.get(shape)[3];
                if (x1 < xTop) xTop = x1;
                if (x2 > xbut) xbut = x2;
                if (y1 < yTop) yTop = y1;
                if (y2 > ybut) ybut = y2;

            } else {
                double x1 = storage.get(shape)[0];
                double x2 = storage.get(shape)[1];
                double x3 = storage.get(shape)[2];
                double y1 = storage.get(shape)[3];
                double y2 = storage.get(shape)[4];
                double y3 = storage.get(shape)[5];

                double xMin = Math.min(x1, Math.min(x2, x3));
                double xMax = Math.max(x1, Math.max(x2, x3));
                double yMin = Math.min(y1, Math.min(y2, y3));
                double yMax = Math.max(y1, Math.max(y2, y3));

                if (xMin < xTop) xTop = xMin;
                if (xMax > xbut) xbut = xMax;
                if (yMin < yTop) yTop = yMin;
                if (yMax > ybut) ybut = yMax;
            }
        }
        length = xbut - xTop;
        width = ybut - yTop;
        Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
        g.setStroke(stroke);
        g.setColor(Color.black);
        g.draw(new Rectangle2D.Double(xTop - 5, yTop - 5, length + 10, width + 10));
        g.setStroke(new BasicStroke(5));


    }

    public void drawSelect(int i, ArrayList<double[]> storage, ArrayList<ShapeType> shapeTypes) {
        Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
        g.setStroke(stroke);
        g.setColor(Color.black);
        if (shapeTypes.get(i).equals(ShapeType.RECTANGLE)) {
            g.draw(new Rectangle2D.Double(storage.get(i)[0] - 5, storage.get(i)[1] - 5, storage.get(i)[2] + 10, storage.get(i)[3] + 10));
        } else if (shapeTypes.get(i).equals(ShapeType.ELLIPSE)) {
            g.draw(new Ellipse2D.Double(storage.get(i)[0] - 5, storage.get(i)[1] - 5, storage.get(i)[2] + 10, storage.get(i)[3] + 10));
        } else if (shapeTypes.get(i).equals(ShapeType.TRIANGLE)) {

            int xMin = Math.min(Math.min((int) storage.get(i)[0], (int) storage.get(i)[1]), (int) storage.get(i)[2]);
            int xMax = Math.max(Math.max((int) storage.get(i)[0], (int) storage.get(i)[1]), (int) storage.get(i)[2]);
            int yMin = Math.min(Math.min((int) storage.get(i)[3], (int) storage.get(i)[4]), (int) storage.get(i)[5]);
            int yMax = Math.max(Math.max((int) storage.get(i)[3], (int) storage.get(i)[4]), (int) storage.get(i)[5]);
            int xMid = (xMax + xMin) / 2;
            int yMid = (yMax + yMin) / 2;
            int[] x = new int[3];
            int[] y = new int[3];
            for (int i2 = 0; i2 < 3; i2++) {
                if (storage.get(i)[i2] < xMid) x[i2] = (int) storage.get(i)[i2] - 5;
                else x[i2] = (int) storage.get(i)[i2] + 5;
            }
            for (int i2 = 3; i2 < 6; i2++) {
                if (storage.get(i)[i2] < yMid) y[i2 - 3] = (int) storage.get(i)[i2] - 5;
                else y[i2 - 3] = (int) storage.get(i)[i2] + 5;
            }
            g.draw(new Polygon(x, y, 3));

        }
        g.setStroke(new BasicStroke(5));

    }

    public void run(ArrayList<Shape> shapeArr,
                    ArrayList<Color> shapePriColor,
                    ArrayList<Color> shapeSecColor,
                    ArrayList<ShapeShadingType> shapeShadingTyp,
                    ArrayList<Shape> selected,
                    ArrayList<double[]> storage,
                    ArrayList<ShapeType> shapeTypes,
                    ArrayList<String> group) {

        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));
        HashSet<String> gOrS = new HashSet<>();
        for (String s : group) {
            gOrS.addAll(Arrays.asList(s.split("")));
        }

        for (int i = 0; i < shapeArr.size(); i++) {
            if (shapeShadingTyp.get(i).equals(ShapeShadingType.FILLED_IN)) {
                g.setColor(shapePriColor.get(i));
                g.fill(shapeArr.get(i));
            } else if (shapeShadingTyp.get(i).equals(ShapeShadingType.OUTLINE)) {
                g.setColor(shapeSecColor.get(i));
                g.draw(shapeArr.get(i));
            } else {
                g.setColor(shapePriColor.get(i));
                g.fill(shapeArr.get(i));
                g.setColor(shapeSecColor.get(i));
                g.draw(shapeArr.get(i));
            }
            if (gOrS.contains(i + "")) drawGroup(i, storage, shapeTypes, group);
            else if (selected.contains(shapeArr.get(i))) drawSelect(i, storage, shapeTypes);

        }
    }

    public void run() {

        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));

        HashSet<String> gOrS = new HashSet<>();
        for (String s : group2) {
            gOrS.addAll(Arrays.asList(s.split("")));
        }

        for (int i = 0; i < shapeArr2.size(); i++) {

            if (shapeShadingTyp2.get(i).equals(ShapeShadingType.FILLED_IN)) {
                g.setColor(shapePriColor2.get(i));
                g.fill(shapeArr2.get(i));
            } else if (shapeShadingTyp2.get(i).equals(ShapeShadingType.OUTLINE)) {
                g.setColor(shapeSecColor2.get(i));
                g.draw(shapeArr2.get(i));
            } else {
                g.setColor(shapePriColor2.get(i));
                g.fill(shapeArr2.get(i));
                g.setColor(shapeSecColor2.get(i));
                g.draw(shapeArr2.get(i));
            }

            if (selected2.contains(shapeArr2.get(i))) {
                if (gOrS.contains(i + "")) {
                    drawGroup(i, storage2, shapeTypes2, group2);
                } else {
                    drawSelect(i, storage2, shapeTypes2);
                }
            }

        }
    }


    public supDrawer(
            Graphics2D g,
            ArrayList<Shape> shapeArr,
            ArrayList<Color> shapePriColor,
            ArrayList<Color> shapeSecColor,
            ArrayList<ShapeShadingType> shapeShadingTyp,
            ArrayList<Shape> selected,
            ArrayList<double[]> storage,
            ArrayList<ShapeType> shapeTypes,
            ArrayList<String> group,

            ArrayList<Shape> shapeArr2,
            ArrayList<Color> shapePriColor2,
            ArrayList<Color> shapeSecColor2,
            ArrayList<ShapeShadingType> shapeShadingTyp2,
            ArrayList<Shape> selected2,
            ArrayList<double[]> storage2,
            ArrayList<ShapeType> shapeTypes2,
            ArrayList<String> group2) {
        this.g = g;
        this.shapeArr = shapeArr;
        this.shapePriColor = shapePriColor;
        this.shapeSecColor = shapeSecColor;
        this.shapeShadingTyp = shapeShadingTyp;
        this.selected = selected;
        this.shapeTypes = shapeTypes;
        this.storage = storage;
        this.group = group;

        this.shapeArr2 = shapeArr2;
        this.shapePriColor2 = shapePriColor2;
        this.shapeSecColor2 = shapeSecColor2;
        this.shapeShadingTyp2 = shapeShadingTyp2;
        this.selected2 = selected2;
        this.shapeTypes2 = shapeTypes2;
        this.storage2 = storage2;
        this.group2 = group2;


        CommandHistory.add(this);


    }

}
