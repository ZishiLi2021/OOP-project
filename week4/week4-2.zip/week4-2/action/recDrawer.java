package action;

import model.MouseMode;
import model.ShapeColor;
import model.ShapeShadingType;
import model.ShapeType;
import model.persistence.ApplicationState;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class recDrawer extends MouseAdapter {
    private Point s;
    private Point e;
    private Graphics2D g;


    private ApplicationState appState;
    private Shape cur;

    Color color;
    Color color2;
    Shape shape;
    ShapeShadingType ss;

    public recDrawer(Graphics2D gra, ApplicationState appState) {
        g = gra;
        this.appState = appState;
    }

    private void setUpSp(Point p) {
        s = p;
    }

    private void setUpEp(Point p) {
        e = p;
    }


    private void draw() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) {
            storage1.add(Arrays.copyOf(d, d.length));

        }

        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group1 = (ArrayList<String>) o.group2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();

        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) {
            storage2.add(Arrays.copyOf(d, d.length));

        }
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group2 = (ArrayList<String>) o.group2.clone();

        ShapeType st = appState.getActiveShapeType();
        shapeTypes2.add(st);
        if (st.equals(ShapeType.RECTANGLE)) {
            shape = new Rectangle2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
            double[] temp = {Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY())};
            storage2.add(temp);
        } else if (st.equals(ShapeType.ELLIPSE)) {
            shape = new Ellipse2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
            double[] temp = {Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY())};
            storage2.add(temp);
        } else {
            int[] x = {(int) s.getX(), (int) e.getX(), (int) e.getX()};
            int[] y = {(int) s.getY(), (int) e.getY(), (int) s.getY()};
            double[] temp = {s.getX(), e.getX(), e.getX(), s.getY(), e.getY(), s.getY()};
            storage2.add(temp);
            shape = new Polygon(x, y, 3);
        }
        ShapeColor sc = appState.getActivePrimaryColor();
        color = getColor(sc.toString());
        ShapeColor sc2 = appState.getActiveSecondaryColor();
        color2 = getColor(sc2.toString());
        ss = appState.getActiveShapeShadingType();
        shapeArr2.add(shape);
        shapePriColor2.add(color);
        shapeSecColor2.add(color2);
        shapeShadingTyp2.add(ss);
        supDrawer sD = new supDrawer(g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,
                group1,

                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2
        );
        o = (supDrawer) CommandHistory.get();
        o.run();


    }

    private Color getColor(String s) {
        try {
            Field filed = Color.class.getDeclaredField(s);
            return (Color) filed.get(null);

        } catch (Exception ex) {
            return Color.red;
        }
    }

    private Shape find(Point2D p) {
        supDrawer o = (supDrawer) CommandHistory.get();
        for (Shape r : o.shapeArr2) {
            if (r.contains(p)) return r;
        }
        return null;
    }

    private void colDectection(Rectangle2D collisionRec) {
        supDrawer o = (supDrawer) CommandHistory.get();

        HashSet<String> gOrS = new HashSet<>();
        for (String s : o.group2) {
            gOrS.addAll(Arrays.asList(s.split("")));
        }
        String ans = "";

        ArrayList<Integer> num;
        HashSet<Integer> done = new HashSet<>();

        ArrayList<Integer> valid = new ArrayList<>();
        for (int i = 0; i < o.shapeArr2.size(); i++) {
            boolean res;
            Shape temp = o.shapeArr2.get(i);
            if (o.shapeTypes2.get(i).equals(ShapeType.ELLIPSE)) {
                res = collisionRec.intersects(new Rectangle2D.Double(o.storage2.get(i)[0], o.storage2.get(i)[1], o.storage2.get(i)[2],
                        o.storage2.get(i)[3]));
            } else if (o.shapeTypes2.get(i).equals(ShapeType.RECTANGLE)) {
                res = temp.intersects(collisionRec);
            } else {
                int xMin = Math.min(Math.min((int) o.storage2.get(i)[0], (int) o.storage2.get(i)[1]), (int) o.storage2.get(i)[2]);
                int xMax = Math.max(Math.max((int) o.storage2.get(i)[0], (int) o.storage2.get(i)[1]), (int) o.storage2.get(i)[2]);
                int yMin = Math.min(Math.min((int) o.storage2.get(i)[3], (int) o.storage2.get(i)[4]), (int) o.storage2.get(i)[5]);
                int yMax = Math.max(Math.max((int) o.storage2.get(i)[3], (int) o.storage2.get(i)[4]), (int) o.storage2.get(i)[5]);
                res = collisionRec.intersects(new Rectangle2D.Double(xMin, yMin, xMax - xMin, yMax - yMin));
            }
            if (res) {
                valid.add(i);

            }
            ;
        }
        for (int v : valid) {
            if (done.contains(v)) {
            } else {
                if (gOrS.contains(v + "")) {
                    for (String s : o.group2) {
                        if (s.contains(v + "") && s.length() > ans.length()) ans = s;
                    }
                    num = new ArrayList<>();
                    for (String s2 : ans.split("")) {
                        num.add(Integer.parseInt(s2));
                        done.add(Integer.parseInt(s2));
                    }

                    for (int i : num) {
                        o.selected2.add(o.shapeArr2.get(i));
                    }
                } else o.selected2.add(o.shapeArr2.get(v));
            }
        }
    }

    private void move() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) storage1.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group1 = (ArrayList<String>) o.group2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) storage2.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();
        ArrayList<String> group2 = (ArrayList<String>) o.group2.clone();


        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));

        int offsetX = e.x - s.x;
        int offsetY = e.y - s.y;

        Shape newShape;
        for (int i = 0; i < o.shapeArr2.size(); i++) {
            if (o.selected2.contains(o.shapeArr2.get(i))) {

                if (!o.shapeTypes2.get(i).equals(ShapeType.TRIANGLE)) {
                    storage2.get(i)[0] += offsetX;
                    storage2.get(i)[1] += offsetY;
                    if (o.shapeTypes2.get(i).equals(ShapeType.RECTANGLE)) {
                        newShape = new Rectangle2D.Double(storage2.get(i)[0], storage2.get(i)[1],
                                storage2.get(i)[2], storage2.get(i)[3]);
                    } else {
                        newShape = new Ellipse2D.Double(storage2.get(i)[0], storage2.get(i)[1],
                                storage2.get(i)[2], storage2.get(i)[3]);
                    }
                } else {
                    int[] newX = new int[3];
                    int[] newY = new int[3];
                    for (int x = 0; x < 3; x++) {
                        int temp = (int) (o.storage2.get(i)[x] + offsetX);

                        newX[x] = temp;
                        storage2.get(i)[x] += offsetX;
                    }
                    for (int y = 0; y < 3; y++) {
                        int temp = (int) (o.storage2.get(i)[y + 3] + offsetY);

                        newY[y] = temp;
                        storage2.get(i)[y + 3] += offsetY;
                    }

                    newShape = new Polygon(newX, newY, 3);


                }
                selected2.set(selected2.indexOf(shapeArr2.get(i)), newShape);
                shapeArr2.set(i, newShape);
            }
        }


        supDrawer sD = new supDrawer(g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,
                group1,

                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2
        );
        o = (supDrawer) CommandHistory.get();
        o.run();

    }


    @Override
    public void mousePressed(MouseEvent event) {
        setUpSp(event.getPoint());
    }

    HashSet<Integer> completed = new HashSet<>();

    @Override
    public void mouseReleased(MouseEvent event) {
        supDrawer o = (supDrawer) CommandHistory.get();
        MouseMode m = appState.getActiveMouseMode();
        setUpEp(event.getPoint());
        cur = find(s);
        if (m.equals(MouseMode.SELECT)) {

            HashSet<String> gOrS = new HashSet<>();
            for (String s : o.group2) {
                gOrS.addAll(Arrays.asList(s.split("")));
            }
            String ans = "";
            String ind = "" + o.shapeArr2.indexOf(cur);
            ArrayList<Integer> num = new ArrayList<>();
            if (gOrS.contains(ind)) {
                for (String s : o.group2) {
                    if (s.contains(ind) && s.length() > ans.length()) ans = s;
                }
                num = new ArrayList<>();
                for (String s2 : ans.split("")) {
                    num.add(Integer.parseInt(s2));
                    completed.add(Integer.parseInt(s2));
                }
            } else num.add(Integer.parseInt(ind));


            if (s.equals(e)) {
                if (cur != null) {
                    if (o.selected2.contains(cur)) {
                        for (int n : num) o.selected2.remove(o.shapeArr2.get(n));

                        o.run();
                    } else {
                        for (int n : num) o.selected2.add(o.shapeArr2.get(n));

                        o.run();
                    }
                } else {
                    o.selected2.clear();
                    completed.clear();

                    o.run();
                }
            } else {
                Rectangle2D collisionRec = new Rectangle2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
                int sel = o.selected2.size();
                colDectection(collisionRec);
                o.run();
              
                if (sel == o.selected2.size()) {
                    o.selected2.clear();
                    o.run();
                }
            }

        } else if (m.equals(MouseMode.DRAW)) {
            o.selected2.clear();
            draw();
        } else if (m.equals(MouseMode.MOVE)) {
            move();
        }
//

    }


}


