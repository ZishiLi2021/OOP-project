package action;

public class PasteCommand implements ICommand {
    public void run() {
        Shop.paste();
    }
}
