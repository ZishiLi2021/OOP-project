package action;

public class CopyCommand implements ICommand {
    @Override
    public void run() {
        Shop.copy();
    }
}
