package action;

import model.MouseMode;
import model.ShapeColor;
import model.ShapeShadingType;
import model.ShapeType;
import model.persistence.ApplicationState;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class recDrawer extends MouseAdapter {
    private Point s;
    private Point e;
    private Graphics2D g;


    private ApplicationState appState;
    private Shape cur;

    Color color;
    Color color2;
    Shape shape;
    ShapeShadingType ss;

    public recDrawer(Graphics2D gra, ApplicationState appState) {
        g = gra;
        this.appState = appState;
    }

    private void setUpSp(Point p) {
        s = p;
    }

    private void setUpEp(Point p) {
        e = p;
    }


    private void draw() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) {
            storage1.add(Arrays.copyOf(d, d.length));

        }

        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();

        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) {
            storage2.add(Arrays.copyOf(d, d.length));

        }
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();


        ShapeType st = appState.getActiveShapeType();
        shapeTypes2.add(st);
        if (st.equals(ShapeType.RECTANGLE)) {
            shape = new Rectangle2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
            double[] temp = {Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY())};
            storage2.add(temp);
        } else if (st.equals(ShapeType.ELLIPSE)) {
            shape = new Ellipse2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
            double[] temp = {Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY())};
            storage2.add(temp);
        } else {
            int[] x = {(int) s.getX(), (int) e.getX(), (int) e.getX()};
            int[] y = {(int) s.getY(), (int) e.getY(), (int) s.getY()};
            double[] temp = {s.getX(), e.getX(), e.getX(), s.getY(), e.getY(), s.getY()};
            storage2.add(temp);
            shape = new Polygon(x, y, 3);
        }
        ShapeColor sc = appState.getActivePrimaryColor();
        color = getColor(sc.toString());
        ShapeColor sc2 = appState.getActiveSecondaryColor();
        color2 = getColor(sc2.toString());
        ss = appState.getActiveShapeShadingType();
        shapeArr2.add(shape);
        shapePriColor2.add(color);
        shapeSecColor2.add(color2);
        shapeShadingTyp2.add(ss);
        supDrawer sD = new supDrawer(g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,


                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2

        );
        o = (supDrawer) CommandHistory.get();
        o.run();


    }

    private Color getColor(String s) {
        try {
            Field filed = Color.class.getDeclaredField(s);
            return (Color) filed.get(null);

        } catch (Exception ex) {
            return Color.red;
        }
    }

    private Shape find(Point2D p) {
        supDrawer o = (supDrawer) CommandHistory.get();
        for (Shape r : o.shapeArr2) {
            if (r.contains(p)) return r;
        }
        return null;
    }

    private void colDectection(Rectangle2D collisionRec) {
        supDrawer o = (supDrawer) CommandHistory.get();


        ArrayList<Integer> num;
        HashSet<Integer> done = new HashSet<>();

//        for (int ind = 0; ind < o.shapeArr2.size(); ind++) {
//            if (done.contains(ind)) continue;
//            num = new ArrayList<>();
//            if (gOrS.contains(ind + "")) {
//                for (String s : o.group2) {
//                    if (s.contains(ind + "") && s.length() > ans.length()) ans = s;
//                }
//                num = new ArrayList<>();
//                for (String s2 : ans.split("")) {
//                    num.add(Integer.parseInt(s2));
//                    done.add(Integer.parseInt(s2));
//                }
//            } else num.add(Integer.parseInt(ind + ""));
//            for (int i : num) {
//
//            }
//        }

        ArrayList<Integer> valid = new ArrayList<>();
        for (int i = 0; i < o.shapeArr2.size(); i++) {
            boolean res;
            Shape temp = o.shapeArr2.get(i);
            if (o.shapeTypes2.get(i).equals(ShapeType.ELLIPSE)) {
                res = collisionRec.intersects(new Rectangle2D.Double(o.storage2.get(i)[0], o.storage2.get(i)[1], o.storage2.get(i)[2],
                        o.storage2.get(i)[3]));
            } else if (o.shapeTypes2.get(i).equals(ShapeType.RECTANGLE)) {
                res = temp.intersects(collisionRec);
            } else {
                int xMin = Math.min(Math.min((int) o.storage2.get(i)[0], (int) o.storage2.get(i)[1]), (int) o.storage2.get(i)[2]);
                int xMax = Math.max(Math.max((int) o.storage2.get(i)[0], (int) o.storage2.get(i)[1]), (int) o.storage2.get(i)[2]);
                int yMin = Math.min(Math.min((int) o.storage2.get(i)[3], (int) o.storage2.get(i)[4]), (int) o.storage2.get(i)[5]);
                int yMax = Math.max(Math.max((int) o.storage2.get(i)[3], (int) o.storage2.get(i)[4]), (int) o.storage2.get(i)[5]);
                res = collisionRec.intersects(new Rectangle2D.Double(xMin, yMin, xMax - xMin, yMax - yMin));
            }
            if (res) {
                valid.add(i);
//                o.selected2.add(o.shapeArr2.get(i));///?????
            }
            ;
        }

    }

    private void move() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) storage1.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();


        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) storage2.add(Arrays.copyOf(d, d.length));
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();


        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));

        int offsetX = e.x - s.x;
        int offsetY = e.y - s.y;

        Shape newShape;
        for (int i = 0; i < o.shapeArr2.size(); i++) {
            if (o.selected2.contains(o.shapeArr2.get(i))) {
//                if (completed.contains(i)) continue;
//                if (gOrS.contains(i + "")) {
//                    String ans = "";
//                    String ind = i + "";
//                    for (String s : group2) {
//                        if (s.contains(ind) && s.length() > ans.length()) ans = s;
//                    }
//                    ArrayList<Integer> num = new ArrayList<>();
//                    for (String s2 : ans.split("")) {
//                        num.add(Integer.parseInt(s2));
//                        completed.add(Integer.parseInt(s2));
//                    }
////                    System.out.println("i = " + i);
////                    System.out.println(num);
////                    System.out.println(completed);
//                    for (int pic : num) {
//                        System.out.println("pic = " + pic + "start");
//                        sup(pic, storage2, offsetX, offsetY, shapeTypes2,
//                                selected2, shapeArr2);
//                    }
//                } else sup(i, storage2, offsetX, offsetY, shapeTypes2,
//                        selected2, shapeArr2);
                if (!o.shapeTypes2.get(i).equals(ShapeType.TRIANGLE)) {
                    storage2.get(i)[0] += offsetX;
                    storage2.get(i)[1] += offsetY;
                    if (o.shapeTypes2.get(i).equals(ShapeType.RECTANGLE)) {
                        newShape = new Rectangle2D.Double(storage2.get(i)[0], storage2.get(i)[1],
                                storage2.get(i)[2], storage2.get(i)[3]);
                    } else {
                        newShape = new Ellipse2D.Double(storage2.get(i)[0], storage2.get(i)[1],
                                storage2.get(i)[2], storage2.get(i)[3]);
                    }
                } else {
                    int[] newX = new int[3];
                    int[] newY = new int[3];
                    for (int x = 0; x < 3; x++) {
                        int temp = (int) (o.storage2.get(i)[x] + offsetX);
                        System.out.println("x = " + temp);
                        newX[x] = temp;
                        storage2.get(i)[x] += offsetX;
                    }
                    for (int y = 0; y < 3; y++) {
                        int temp = (int) (o.storage2.get(i)[y + 3] + offsetY);
                        System.out.println("y = " + temp);
                        newY[y] = temp;
                        storage2.get(i)[y + 3] += offsetY;
                    }
                    for (int q : newY) System.out.print(q);
                    System.out.println();
                    newShape = new Polygon(newX, newY, 3);
                    for (int qq : newY) System.out.println(qq);


                    System.out.println(newShape.toString());
                }
                selected2.set(selected2.indexOf(shapeArr2.get(i)), newShape);
                shapeArr2.set(i, newShape);
            }
        }


        supDrawer sD = new supDrawer(g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,


                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2

        );
        o = (supDrawer) CommandHistory.get();
        o.run();

    }

//    private void sup(int i, ArrayList<double[]> storage2, int offsetX, int offsetY, ArrayList<ShapeType> shapeTypes2,
//                     ArrayList<Shape> selected2, ArrayList<Shape> shapeArr2) {
//        Shape newShape;
//        if (!shapeTypes2.get(i).equals(ShapeType.TRIANGLE)) {
//
//            storage2.get(i)[0] += offsetX;
//            storage2.get(i)[1] += offsetY;
//
//
//            if (shapeTypes2.get(i).equals(ShapeType.RECTANGLE)) {
//                newShape = new Rectangle2D.Double(storage2.get(i)[0], storage2.get(i)[1],
//                        storage2.get(i)[2], storage2.get(i)[3]);
//            } else {
//                newShape = new Ellipse2D.Double(storage2.get(i)[0], storage2.get(i)[1],
//                        storage2.get(i)[2], storage2.get(i)[3]);
//            }
//
//
//        } else {
//            int[] newX = new int[3];
//            int[] newY = new int[3];
//            for (int x = 0; x < 3; x++) {
//                newX[x] = (int) storage2.get(i)[x] + offsetX;
//                storage2.get(i)[x] += offsetX;
//            }
//            for (int y = 0; y < 3; y++) {
//                newX[y] = (int) storage2.get(i)[y + 3] + offsetY;
//                storage2.get(i)[y + 3] += offsetY;
//            }
//            newShape = new Polygon(newX, newY, 3);
//        }
//        System.out.println("new shape = " + shape);
//        System.out.print("i = " + i);
//        System.out.println("selected2 below");
//        System.out.println(selected2);
//        System.out.println("shape arr2 below");
//        System.out.println(shapeArr2);
//        System.out.println(shapeArr2.get(i));
//        selected2.set(selected2.indexOf(shapeArr2.get(i)), newShape);
//        shapeArr2.set(i, newShape);
//    }


//    public void run() {
//        supDrawer o = (supDrawer) CommandHistory.get();
//
//        g.setColor(Color.WHITE);
//        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));
//        for (int i = 0; i < o.shapeArr2.size(); i++) {
//            if (o.shapeShadingTyp2.get(i).equals(ShapeShadingType.FILLED_IN)) {
//                g.setColor(o.shapePriColor2.get(i));
//                g.fill(o.shapeArr2.get(i));
//            } else if (o.shapeShadingTyp2.get(i).equals(ShapeShadingType.OUTLINE)) {
//                g.setColor(o.shapeSecColor2.get(i));
//                g.draw(o.shapeArr2.get(i));
//            } else {
//                g.setColor(o.shapePriColor2.get(i));
//                g.fill(o.shapeArr2.get(i));
//                g.setColor(o.shapeSecColor2.get(i));
//                g.draw(o.shapeArr2.get(i));
//            }
//            if (o.selected2.contains(o.shapeArr2.get(i))) {
//                Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
//                g.setStroke(stroke);
//                g.setColor(Color.black);
//                if (o.shapeTypes2.get(i).equals(ShapeType.RECTANGLE)) {
//                    g.draw(new Rectangle2D.Double(o.storage2.get(i)[0] - 5, o.storage2.get(i)[1] - 5, o.storage2.get(i)[2] + 10, o.storage2.get(i)[3] + 10));
//                } else if (o.shapeTypes2.get(i).equals(ShapeType.ELLIPSE)) {
//                    g.draw(new Ellipse2D.Double(o.storage2.get(i)[0] - 5, o.storage2.get(i)[1] - 5, o.storage2.get(i)[2] + 10, o.storage2.get(i)[3] + 10));
//                } else if (o.shapeTypes2.get(i).equals(ShapeType.TRIANGLE)) {
//
//                    int xMin = Math.min(Math.min((int) o.storage2.get(i)[0], (int) o.storage2.get(i)[1]), (int) o.storage2.get(i)[2]);
//                    int xMax = Math.max(Math.max((int) o.storage2.get(i)[0], (int) o.storage2.get(i)[1]), (int) o.storage2.get(i)[2]);
//                    int yMin = Math.min(Math.min((int) o.storage2.get(i)[3], (int) o.storage2.get(i)[4]), (int) o.storage2.get(i)[5]);
//                    int yMax = Math.max(Math.max((int) o.storage2.get(i)[3], (int) o.storage2.get(i)[4]), (int) o.storage2.get(i)[5]);
//                    int xMid = (xMax + xMin) / 2;
//                    int yMid = (yMax + yMin) / 2;
//                    int[] x = new int[3];
//                    int[] y = new int[3];
//                    for (int i2 = 0; i2 < 3; i2++) {
//                        if (o.storage2.get(i)[i2] < xMid) x[i2] = (int) o.storage2.get(i)[i2] - 5;
//                        else x[i2] = (int) o.storage2.get(i)[i2] + 5;
//                    }
//                    for (int i2 = 3; i2 < 6; i2++) {
//                        if (o.storage2.get(i)[i2] < yMid) y[i2 - 3] = (int) o.storage2.get(i)[i2] - 5;
//                        else y[i2 - 3] = (int) o.storage2.get(i)[i2] + 5;
//                    }
//                    g.draw(new Polygon(x, y, 3));
//                    g.setStroke(new BasicStroke(5));
//                }
//            }
//
//        }
//    }


    @Override
    public void mousePressed(MouseEvent event) {
        setUpSp(event.getPoint());
    }

    HashSet<Integer> completed = new HashSet<>();

    @Override
    public void mouseReleased(MouseEvent event) {
        supDrawer o = (supDrawer) CommandHistory.get();
        MouseMode m = appState.getActiveMouseMode();
        setUpEp(event.getPoint());
        cur = find(s);
        if (m.equals(MouseMode.SELECT)) {

            HashSet<String> gOrS = new HashSet<>();

            String ans = "";
            String ind = "" + o.shapeArr2.indexOf(cur);
            ArrayList<Integer> num = new ArrayList<>();
            if (gOrS.contains(ind)) {
                
                num = new ArrayList<>();
                for (String s2 : ans.split("")) {
                    num.add(Integer.parseInt(s2));
                    completed.add(Integer.parseInt(s2));
                }
            } else num.add(Integer.parseInt(ind));


            if (s.equals(e)) {
                if (cur != null) {
                    if (o.selected2.contains(cur)) {
                        for (int n : num) o.selected2.remove(o.shapeArr2.get(n));
                        System.out.println("remove ! " + o.selected2);
                        o.run();
                    } else {
                        for (int n : num) o.selected2.add(o.shapeArr2.get(n));
                        System.out.println("add ! " + o.selected2);
                        o.run();
                    }
                } else {
                    o.selected2.clear();
                    completed.clear();
                    System.out.println("clear ! " + o.selected2);
                    o.run();
                }
            } else {
                Rectangle2D collisionRec = new Rectangle2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
                int sel = o.selected2.size();
                colDectection(collisionRec);
                o.run();
                System.out.println("test" + o.selected2);
                if (sel == o.selected2.size()) {
                    o.selected2.clear();
                    o.run();
                }
            }

        } else if (m.equals(MouseMode.DRAW)) {
            o.selected2.clear();
            draw();
        } else if (m.equals(MouseMode.MOVE)) {
            move();
        }
//

    }


}


