package action;

import model.MouseMode;
import model.ShapeShadingType;
import model.persistence.ApplicationState;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.lang.reflect.Field;
import java.util.HashSet;

public class recDrawer extends MouseAdapter {
    private Point s;
    private Point e;
    private Graphics2D g;


    private ApplicationState appState;
    private Shape cur;

    Color color;
    Color color2;
    Shape shape;
    ShapeShadingType ss;

    public recDrawer(Graphics2D gra, ApplicationState appState) {
        g = gra;
        this.appState = appState;
    }

    private void setUpSp(Point p) {
        s = p;
    }

    private void setUpEp(Point p) {
        e = p;
    }


    private Color getColor(String s) {
        try {
            Field filed = Color.class.getDeclaredField(s);
            return (Color) filed.get(null);

        } catch (Exception ex) {
            return Color.red;
        }
    }

    private Shape find(Point2D p) {
        supDrawer o = (supDrawer) CommandHistory.get();
        for (Shape r : o.shapeArr2) {
            if (r.contains(p)) return r;
        }
        return null;
    }


    @Override
    public void mousePressed(MouseEvent event) {
        setUpSp(event.getPoint());
    }

    HashSet<Integer> completed = new HashSet<>();

    @Override
    public void mouseReleased(MouseEvent event) {
        supDrawer o = (supDrawer) CommandHistory.get();
        MouseMode m = appState.getActiveMouseMode();
        setUpEp(event.getPoint());
        cur = find(s);


    }


}


