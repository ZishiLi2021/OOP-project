package main;

import action.recDrawer;
import action.supDrawer;
import controller.IJPaintController;
import controller.JPaintController;
import model.ShapeShadingType;
import model.ShapeType;
import model.persistence.ApplicationState;
import view.gui.Gui;
import view.gui.GuiWindow;
import view.gui.PaintCanvas;
import view.interfaces.IGuiWindow;
import view.interfaces.IUiModule;
import view.interfaces.PaintCanvasBase;

import java.awt.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        PaintCanvasBase paintCanvas = new PaintCanvas();
        IGuiWindow guiWindow = new GuiWindow(paintCanvas);
        IUiModule uiModule = new Gui(guiWindow);
        ApplicationState appState = new ApplicationState(uiModule);
        IJPaintController controller = new JPaintController(uiModule, appState);
        controller.setup();

        Graphics2D g = paintCanvas.getGraphics2D();
        g.setStroke(new BasicStroke(5));
        recDrawer rD = new recDrawer(g, appState);
        paintCanvas.addMouseListener(rD);

        ArrayList<Shape> shapeArr1 = new ArrayList<>();
        ArrayList<Color> shapePriColor1 = new ArrayList<>();
        ArrayList<Color> shapeSecColor1 = new ArrayList<>();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = new ArrayList<>();
        ArrayList<Shape> selected1 = new ArrayList<>();
        ArrayList<double[]> storage1 = new ArrayList<>();
        ArrayList<ShapeType> shapeTypes1 = new ArrayList<>();
        ArrayList<String> group1 = new ArrayList<>();
        ArrayList<Shape> shapeArr2 = new ArrayList<>();
        ArrayList<Color> shapePriColor2 = new ArrayList<>();
        ArrayList<Color> shapeSecColor2 = new ArrayList<>();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = new ArrayList<>();
        ArrayList<Shape> selected2 = new ArrayList<>();
        ArrayList<double[]> storage2 = new ArrayList<>();
        ArrayList<ShapeType> shapeTypes2 = new ArrayList<>();
        ArrayList<String> group2 = new ArrayList<>();
        supDrawer sD = new supDrawer(g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,
                group1,

                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2,
                group2
        );


//        try {
//            Thread.sleep(500);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        g.setColor(Color.GREEN);
//        g.fillRect(12, 13, 200, 400);
////
////        // Outlined rectangle
//        g.setStroke(new BasicStroke(5));
//        g.setColor(Color.BLUE);
//        g.drawRect(12, 13, 200, 400);
//
//        // Selected Shape
//        Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
//        g.setStroke(stroke);
//        g.setColor(Color.BLACK);
//        g.drawRect(17, 13, 210, 410);


    }
}
