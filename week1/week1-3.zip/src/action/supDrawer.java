package action;

import model.ShapeShadingType;
import model.ShapeType;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class supDrawer implements IUndoable {
    Graphics2D g;
    public final ArrayList<Shape> shapeArr;
    public final ArrayList<Color> shapePriColor;
    public final ArrayList<Color> shapeSecColor;
    public final ArrayList<ShapeShadingType> shapeShadingTyp;
    public final ArrayList<Shape> selected;
    public final ArrayList<double[]> storage;
    public final ArrayList<ShapeType> shapeTypes;


    public final ArrayList<Shape> shapeArr2;
    public final ArrayList<Color> shapePriColor2;
    public final ArrayList<Color> shapeSecColor2;
    public final ArrayList<ShapeShadingType> shapeShadingTyp2;
    public final ArrayList<Shape> selected2;
    public final ArrayList<double[]> storage2;
    public final ArrayList<ShapeType> shapeTypes2;


    @Override
    public void undo() {
        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));
        run(shapeArr,
                shapePriColor,
                shapeSecColor,
                shapeShadingTyp,
                selected,
                storage,
                shapeTypes
        );
    }

    @Override
    public void redo() {
        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));
        run(shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2
        );
    }


    public void run(ArrayList<Shape> shapeArr,
                    ArrayList<Color> shapePriColor,
                    ArrayList<Color> shapeSecColor,
                    ArrayList<ShapeShadingType> shapeShadingTyp,
                    ArrayList<Shape> selected,
                    ArrayList<double[]> storage,
                    ArrayList<ShapeType> shapeTypes
    ) {

        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));


        for (int i = 0; i < shapeArr.size(); i++) {
            if (shapeShadingTyp.get(i).equals(ShapeShadingType.FILLED_IN)) {
                g.setColor(shapePriColor.get(i));
                g.fill(shapeArr.get(i));
            } else if (shapeShadingTyp.get(i).equals(ShapeShadingType.OUTLINE)) {
                g.setColor(shapeSecColor.get(i));
                g.draw(shapeArr.get(i));
            } else {
                g.setColor(shapePriColor.get(i));
                g.fill(shapeArr.get(i));
                g.setColor(shapeSecColor.get(i));
                g.draw(shapeArr.get(i));
            }


        }
    }

    public void run() {

        g.setColor(Color.WHITE);
        g.fill(new Rectangle2D.Double(0, 0, 1250, 800));


        for (int i = 0; i < shapeArr2.size(); i++) {

            if (shapeShadingTyp2.get(i).equals(ShapeShadingType.FILLED_IN)) {
                g.setColor(shapePriColor2.get(i));
                g.fill(shapeArr2.get(i));
            } else if (shapeShadingTyp2.get(i).equals(ShapeShadingType.OUTLINE)) {
                g.setColor(shapeSecColor2.get(i));
                g.draw(shapeArr2.get(i));
            } else {
                g.setColor(shapePriColor2.get(i));
                g.fill(shapeArr2.get(i));
                g.setColor(shapeSecColor2.get(i));
                g.draw(shapeArr2.get(i));
            }


        }
    }


    public supDrawer(
            Graphics2D g,
            ArrayList<Shape> shapeArr,
            ArrayList<Color> shapePriColor,
            ArrayList<Color> shapeSecColor,
            ArrayList<ShapeShadingType> shapeShadingTyp,
            ArrayList<Shape> selected,
            ArrayList<double[]> storage,
            ArrayList<ShapeType> shapeTypes,

            ArrayList<Shape> shapeArr2,
            ArrayList<Color> shapePriColor2,
            ArrayList<Color> shapeSecColor2,
            ArrayList<ShapeShadingType> shapeShadingTyp2,
            ArrayList<Shape> selected2,
            ArrayList<double[]> storage2,
            ArrayList<ShapeType> shapeTypes2
    ) {
        this.g = g;
        this.shapeArr = shapeArr;
        this.shapePriColor = shapePriColor;
        this.shapeSecColor = shapeSecColor;
        this.shapeShadingTyp = shapeShadingTyp;
        this.selected = selected;
        this.shapeTypes = shapeTypes;
        this.storage = storage;


        this.shapeArr2 = shapeArr2;
        this.shapePriColor2 = shapePriColor2;
        this.shapeSecColor2 = shapeSecColor2;
        this.shapeShadingTyp2 = shapeShadingTyp2;
        this.selected2 = selected2;
        this.shapeTypes2 = shapeTypes2;
        this.storage2 = storage2;


        CommandHistory.add(this);


    }

}
