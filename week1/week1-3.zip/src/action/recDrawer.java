package action;

import model.MouseMode;
import model.ShapeColor;
import model.ShapeShadingType;
import model.ShapeType;
import model.persistence.ApplicationState;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class recDrawer extends MouseAdapter {
    private Point s;
    private Point e;
    private Graphics2D g;


    private ApplicationState appState;
    private Shape cur;

    Color color;
    Color color2;
    Shape shape;
    ShapeShadingType ss;

    public recDrawer(Graphics2D gra, ApplicationState appState) {
        g = gra;
        this.appState = appState;
    }

    private void setUpSp(Point p) {
        s = p;
    }

    private void setUpEp(Point p) {
        e = p;
    }


    private void draw() {
        supDrawer o = (supDrawer) CommandHistory.get();
        ArrayList<Shape> shapeArr1 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor1 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor1 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp1 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected1 = (ArrayList<Shape>) o.selected2.clone();
        ArrayList<double[]> storage1 = new ArrayList<>();
        for (double[] d : o.storage2) {
            storage1.add(Arrays.copyOf(d, d.length));

        }

        ArrayList<ShapeType> shapeTypes1 = (ArrayList<ShapeType>) o.shapeTypes2.clone();

        ArrayList<Shape> shapeArr2 = (ArrayList<Shape>) o.shapeArr2.clone();
        ArrayList<Color> shapePriColor2 = (ArrayList<Color>) o.shapePriColor2.clone();
        ArrayList<Color> shapeSecColor2 = (ArrayList<Color>) o.shapeSecColor2.clone();
        ArrayList<ShapeShadingType> shapeShadingTyp2 = (ArrayList<ShapeShadingType>) o.shapeShadingTyp2.clone();
        ArrayList<Shape> selected2 = (ArrayList<Shape>) o.selected2.clone();

        ArrayList<double[]> storage2 = new ArrayList<>();
        for (double[] d : o.storage2) {
            storage2.add(Arrays.copyOf(d, d.length));

        }
        ArrayList<ShapeType> shapeTypes2 = (ArrayList<ShapeType>) o.shapeTypes2.clone();


        ShapeType st = appState.getActiveShapeType();
        shapeTypes2.add(st);
        if (st.equals(ShapeType.RECTANGLE)) {
            shape = new Rectangle2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
            double[] temp = {Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY())};
            storage2.add(temp);
        }
        ShapeColor sc = appState.getActivePrimaryColor();
        color = getColor(sc.toString());
        ShapeColor sc2 = appState.getActiveSecondaryColor();
        color2 = getColor(sc2.toString());
        ss = appState.getActiveShapeShadingType();
        shapeArr2.add(shape);
        shapePriColor2.add(color);
        shapeSecColor2.add(color2);
        shapeShadingTyp2.add(ss);
        supDrawer sD = new supDrawer(g,
                shapeArr1,
                shapePriColor1,
                shapeSecColor1,
                shapeShadingTyp1,
                selected1,
                storage1,
                shapeTypes1,


                shapeArr2,
                shapePriColor2,
                shapeSecColor2,
                shapeShadingTyp2,
                selected2,
                storage2,
                shapeTypes2

        );
        o = (supDrawer) CommandHistory.get();
        o.run();


    }

    private Color getColor(String s) {
        try {
            Field filed = Color.class.getDeclaredField(s);
            return (Color) filed.get(null);

        } catch (Exception ex) {
            return Color.red;
        }
    }

    private Shape find(Point2D p) {
        supDrawer o = (supDrawer) CommandHistory.get();
        for (Shape r : o.shapeArr2) {
            if (r.contains(p)) return r;
        }
        return null;
    }


    @Override
    public void mousePressed(MouseEvent event) {
        setUpSp(event.getPoint());
    }

    HashSet<Integer> completed = new HashSet<>();

    @Override
    public void mouseReleased(MouseEvent event) {
        supDrawer o = (supDrawer) CommandHistory.get();
        MouseMode m = appState.getActiveMouseMode();
        setUpEp(event.getPoint());
        cur = find(s);


        draw();
    

    }


}


