package main;

import action.recDrawer;
import controller.IJPaintController;
import controller.JPaintController;
import model.persistence.ApplicationState;
import view.gui.Gui;
import view.gui.GuiWindow;
import view.gui.PaintCanvas;
import view.interfaces.IGuiWindow;
import view.interfaces.IUiModule;
import view.interfaces.PaintCanvasBase;

import java.awt.*;

public class Main {
    public static void main(String[] args) {
        PaintCanvasBase paintCanvas = new PaintCanvas();
        IGuiWindow guiWindow = new GuiWindow(paintCanvas);
        IUiModule uiModule = new Gui(guiWindow);
        ApplicationState appState = new ApplicationState(uiModule);
        IJPaintController controller = new JPaintController(uiModule, appState);
        controller.setup();


        Graphics2D g = paintCanvas.getGraphics2D();
        g.setStroke(new BasicStroke(5));
        recDrawer rD = new recDrawer(g, appState);
        paintCanvas.addMouseListener(rD);


//        try {
//            Thread.sleep(500);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        g.setColor(Color.GREEN);
//        g.fillRect(12, 13, 200, 400);
//
//        // Outlined rectangle
//        g.setStroke(new BasicStroke(5));
//        g.setColor(Color.BLUE);
//        g.drawRect(12, 13, 200, 400);
//
//        // Selected Shape
//        Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
//        g.setStroke(stroke);
//        g.setColor(Color.BLACK);
//        g.drawRect(7, 8, 210, 410);
    }
}
