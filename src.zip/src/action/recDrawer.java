package action;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class recDrawer extends MouseAdapter {
    private Point s;
    private Point e;
    private Graphics2D g;
    private ArrayList<Rectangle2D> a = new ArrayList<>();

    public recDrawer(Graphics2D gra) {
        g = gra;
    }

    private void setUpSp(Point p) {
        s = p;
    }

    private void setUpEp(Point p) {
        e = p;
    }

    private void run() {
        Rectangle2D rec = new Rectangle2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
        a.add(rec);


        supDrawer sD = new supDrawer(g, rec, a);
        sD.drawS();
    }


    @Override
    public void mousePressed(MouseEvent event) {
        setUpSp(event.getPoint());

    }

    @Override
    public void mouseReleased(MouseEvent event) {
        setUpEp(event.getPoint());
        run();
    }
}
