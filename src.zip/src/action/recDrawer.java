package action;

import model.MouseMode;
import model.ShapeColor;
import model.ShapeShadingType;
import model.ShapeType;
import model.persistence.ApplicationState;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.ArrayList;

public class recDrawer extends MouseAdapter {
    private Point s;
    private Point e;
    private Graphics2D g;
    private ArrayList<Shape> aS = new ArrayList<>();
    private ArrayList<Color> aC = new ArrayList<>();
    private ArrayList<Color> aC2 = new ArrayList<>();
    private ArrayList<ShapeShadingType> ty = new ArrayList<>();
    private ApplicationState appState;
    private ArrayList<Shape> selected = new ArrayList<>();
    private ArrayList<double[]> storage = new ArrayList<>();
    private ArrayList<ShapeType> shapeTypes = new ArrayList<>();

    private Shape cur;
    Color color;
    Color color2;
    Shape shape;
    ShapeShadingType ss;

    public recDrawer(Graphics2D gra, ApplicationState appState) {
        g = gra;
        this.appState = appState;
    }

    private void setUpSp(Point p) {
        s = p;
    }

    private void setUpEp(Point p) {
        e = p;
    }

    private void run() {


        ShapeType st = appState.getActiveShapeType();
        shapeTypes.add(st);
        if (st.equals(ShapeType.RECTANGLE)) {
            shape = new Rectangle2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
            double[] temp = {Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY())};
            storage.add(temp);
        } else if (st.equals(ShapeType.ELLIPSE)) {
            shape = new Ellipse2D.Double(Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY()));
            double[] temp = {Math.min(s.getX(), e.getX()), Math.min(s.getY(), e.getY()), Math.abs(e.getX() - s.getX()), Math.abs(e.getY() - s.getY())};
            storage.add(temp);
        } else {
            int[] x = {(int) s.getX(), (int) e.getX(), (int) e.getX()};
            int[] y = {(int) s.getY(), (int) e.getY(), (int) s.getY()};
            double[] temp = {s.getX(), e.getX(), e.getX(), s.getY(), e.getY(), s.getY()};
            storage.add(temp);
            shape = new Polygon(x, y, 3);
        }

        ShapeColor sc = appState.getActivePrimaryColor();
        color = getColor(sc.toString());


        ShapeColor sc2 = appState.getActiveSecondaryColor();
        color2 = getColor(sc2.toString());


        ss = appState.getActiveShapeShadingType();


        aS.add(shape);
        aC.add(color);
        aC2.add(color2);
        ty.add(ss);
        supDrawer sD = new supDrawer(g, shape, aS, color, aC, color2, aC2, ss, ty);
        sD.drawS();
    }

    private Color getColor(String s) {
        try {
            Field filed = Color.class.getDeclaredField(s);
            return (Color) filed.get(null);

        } catch (Exception ex) {
            return Color.red;
        }
    }

    private Shape find(Point2D p) {
        for (Shape r : aS) {
            if (r.contains(p)) return r;
        }
        return null;
    }


    @Override
    public void mousePressed(MouseEvent event) {
        setUpSp(event.getPoint());
        MouseMode m = appState.getActiveMouseMode();
        cur = find(event.getPoint());

        if (m.equals(MouseMode.SELECT)) {
            if (cur != null) {
                if (selected.contains(cur)) {
                    selected.remove(cur);
                } else {
                    selected.add(cur);
                }
            }
        }
    }


    @Override
    public void mouseReleased(MouseEvent event) {
        MouseMode m = appState.getActiveMouseMode();
        setUpEp(event.getPoint());
        if (m.equals(MouseMode.DRAW)) {
            run();
        }
//        if (m.equals(MouseMode.MOVE)) {
//
//            for (Shape a : selected) {
//                int ind = aS.indexOf(a);
//                g.setColor(Color.white);
//                g.fill(a);
//
//                selected.remove(a);
//                if (a.toString().charAt(14) == 'R') {
//                    a = new Rectangle2D.Double(e.x, e.y, storage.get(ind)[2], storage.get(ind)[3]);
//                } else if (a.toString().charAt(14) == 'E') {
//                    a = new Ellipse2D.Double(e.x, e.y, storage.get(ind)[2], storage.get(ind)[3]);
//                }
//                storage.get(ind)[0] = e.x;
//                storage.get(ind)[1] = e.y;
//                selected.add(ind, a);
//
//                g.setColor(aC.get(ind));
//                g.fill(a);
//            }

    }


}


