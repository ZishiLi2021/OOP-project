package action;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class supDrawer implements IUndoable {
    Graphics2D g;
    Rectangle2D rec;
    ArrayList<Rectangle2D> a;

    @Override
    public void undo() {
        g.setColor(Color.white);
        for (Rectangle2D r : a) {
            g.fill(r);
        }
        g.setColor(Color.black);
        for (int i = 0; i < a.size() - 1; i++) {

            g.fill(a.get(i));
        }
        if (!a.isEmpty()) a.remove(a.size() - 1);

    }

    @Override
    public void redo() {
        g.fill(rec);
        a.add(rec);
    }

    public void drawS() {
        g.fill(rec);
        CommandHistory.add(this);
    }

    public supDrawer(Graphics2D g, Rectangle2D rec, ArrayList<Rectangle2D> a) {
        this.g = g;
        this.rec = rec;
        this.a = a;

    }
}
