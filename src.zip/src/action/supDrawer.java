package action;

import model.ShapeShadingType;

import java.awt.*;
import java.util.ArrayList;

public class supDrawer implements IUndoable {
    Graphics2D g;

    Shape shape;
    Color color;
    Color color2;
    ShapeShadingType type;

    ArrayList<Shape> a;
    ArrayList<Color> a2;
    ArrayList<Color> a22;
    ArrayList<ShapeShadingType> ty;
//    ArrayList<Shape> selected;
//    double[] offset;
//    ArrayList<ShapeType> shapeTypes;
//    ArrayList<double[]> storage;
//
//
//    private ArrayList<Color> aC;
//    private ArrayList<Color> aC2;
//    private ArrayList<ShapeType> st;

    @Override
    public void undo() {
        g.setColor(Color.white);
        for (Shape s : a) {
            g.fill(s);
            g.draw(s);
        }
        for (int i = 0; i < a.size() - 1; i++) {

            if (ty.get(i).equals(ShapeShadingType.OUTLINE)) {
                g.setColor(a22.get(i));
                g.draw(a.get(i));

            } else if (ty.get(i).equals(ShapeShadingType.FILLED_IN)) {
                g.setColor(a2.get(i));
                g.fill(a.get(i));
            } else {
                g.setColor(a2.get(i));
                g.fill(a.get(i));

                g.setColor(a22.get(i));
                g.draw(a.get(i));

            }
        }

        if (!a.isEmpty()) {
            a.remove(a.size() - 1);
            a2.remove(a2.size() - 1);
            a22.remove(a22.size() - 1);
            ty.remove(ty.size() - 1);
        }

    }

    @Override
    public void redo() {
        if (type.equals(ShapeShadingType.OUTLINE)) {
            g.setColor(color2);
            g.draw(shape);
        } else if (type.equals(ShapeShadingType.FILLED_IN)) {
            g.setColor(color);
            g.fill(shape);
        } else {
            g.setColor(color);
            g.fill(shape);
            g.setColor(color2);
            g.draw(shape);
        }
        a.add(shape);
        a2.add(color);
        a22.add(color2);
        ty.add(type);
    }

    public void drawS() {

        if (type.equals(ShapeShadingType.OUTLINE)) {
            g.setColor(color2);
            g.draw(shape);
        } else if (type.equals(ShapeShadingType.FILLED_IN)) {
            g.setColor(color);
            g.fill(shape);
        } else {
            g.setColor(color);
            g.fill(shape);
            g.setColor(color2);
            g.draw(shape);
        }
    }

//    public void move() {
//        g.setColor(Color.white);
//        for (Shape s : a) {
//            g.fill(s);
//            g.draw(s);
//        }
//
//        for (Shape s : a) {
//            if (selected.contains(s)) {
//                System.out.println("baohan !" + s);
//                int ind = a.indexOf(s);
//                System.out.println("ind =" + ind);
//                Shape temp;
//                System.out.println(storage);
//                storage.get(ind)[0] -= offset[0];
//                storage.get(ind)[1] -= offset[1];
//                if (shapeTypes.get(ind).equals(ShapeType.RECTANGLE)) {
//                    temp = new Rectangle2D.Double(storage.get(ind)[0], storage.get(ind)[1], storage.get(ind)[2], storage.get(ind)[3]);
//                } else if (shapeTypes.get(ind).equals(ShapeType.ELLIPSE)) {
//                    temp = new Ellipse2D.Double(storage.get(ind)[0], storage.get(ind)[1], storage.get(ind)[2], storage.get(ind)[3]);
//                } else {
//                    for (int i = 0; i < 3; i++) {
//                        storage.get(ind)[i] -= offset[0];
//                        storage.get(ind)[i + 3] -= offset[1];
//                    }
//                    int[] x1 = {(int) storage.get(ind)[0], (int) storage.get(ind)[1], (int) storage.get(ind)[2]};
//                    int[] y1 = {(int) storage.get(ind)[3], (int) storage.get(ind)[4], (int) storage.get(ind)[4]};
//                    temp = new Polygon(x1, y1, 3);
//                }
//                a.remove(s);
//                a.add(temp);
//                g.setColor(aC.get(ind));
//                g.draw(temp);
//            } else {
//                int ind = a.indexOf(s);
//                if (shapeTypes.get(ind).equals(ShapeShadingType.OUTLINE)) {
//                    g.setColor(aC2.get(ind));
//                    g.draw(s);
//                } else if (shapeTypes.get(ind).equals(ShapeShadingType.FILLED_IN)) {
//                    g.setColor(aC.get(ind));
//                    g.fill(s);
//                } else {
//                    g.setColor(aC.get(ind));
//                    g.fill(s);
//                    g.setColor(aC2.get(ind));
//                    g.draw(s);
//                }
//            }
//        }
//    }

    public supDrawer(Graphics2D g, Shape shape, ArrayList<Shape> a, Color color, ArrayList<Color> a2, Color color2, ArrayList<Color> a22, ShapeShadingType type, ArrayList<ShapeShadingType> ty) {
        this.g = g;
        this.shape = shape;
        this.a = a;
        this.a2 = a2;
        this.color = color;
        this.color2 = color2;
        this.a22 = a22;
        this.type = type;
        this.ty = ty;
        CommandHistory.add(this);
    }

//    public supDrawer(Graphics2D g,
//                     ArrayList<Shape> a,
//                     ArrayList<Color> aC,
//                     ArrayList<Color> aC2,
//                     ArrayList<ShapeType> st, double[] offset, ArrayList<Shape> selected, ArrayList<ShapeType> shapeTypes, ArrayList<double[]> storage) {
//        this.g = g;
//        this.a = a;
//        this.aC = aC;
//        this.aC2 = aC2;
//        this.st = st;
//        this.offset = offset;
//        this.selected = selected;
//        this.shapeTypes = shapeTypes;
//        this.storage = storage;
//        CommandHistory.add(this);
//    }
}
