package action;

import model.ShapeShadingType;
import model.ShapeType;

import java.awt.*;
import java.util.ArrayList;

public class obj {
    Graphics2D g;
    public ArrayList<Shape> shapeArr;
    public ArrayList<Color> shapePriColor;
    public ArrayList<Color> shapeSecColor;
    public ArrayList<ShapeShadingType> shapeShadingTyp;
    public ArrayList<Shape> selected;
    public ArrayList<double[]> storage;
    public ArrayList<ShapeType> shapeTypes;

    public ArrayList<Shape> getShapeArr() {
        return shapeArr;
    }


    public obj(
            Graphics2D g,
            ArrayList<Shape> shapeArr,
            ArrayList<Color> shapePriColor,
            ArrayList<Color> shapeSecColor,
            ArrayList<ShapeShadingType> shapeShadingTyp,
            ArrayList<Shape> selected,
            ArrayList<double[]> storage,
            ArrayList<ShapeType> shapeTypes

    ) {
        this.g = g;
        this.shapeArr = shapeArr;
        this.shapePriColor = shapePriColor;
        this.shapeSecColor = shapeSecColor;
        this.shapeShadingTyp = shapeShadingTyp;
        this.selected = selected;
        this.shapeTypes = shapeTypes;
        this.storage = storage;

    }
}
